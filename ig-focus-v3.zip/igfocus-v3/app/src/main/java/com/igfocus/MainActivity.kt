package com.igfocus

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.btnGo).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        val tv = findViewById<TextView>(R.id.tvStatus)
        if (isEnabled()) {
            tv.text = "✅  Active — open Instagram to see it working"
            tv.setTextColor(0xFF4ade80.toInt())
        } else {
            tv.text = "⚠️  Tap below → find \"IG Focus Overlay\" → turn it on"
            tv.setTextColor(0xFFf59e0b.toInt())
        }
    }

    private fun isEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("com.igfocus/com.igfocus.FocusService")
    }
}
