package com.igfocus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * IG Focus — Full Overlay Service  v3
 *
 * Turns Instagram into a messaging-only app:
 *
 *  HOME FEED
 *  ┌──────────────────────────┐
 *  │  Header  (free)          │
 *  │  Stories row  (free)     │ ← horizontal swipe between stories works
 *  ├──────────────────────────┤ ← storyBottom
 *  │  🔒 FEED BLOCK           │ ← tap → opens DMs
 *  ├──────────────────────────┤ ← navBar.top
 *  │ 🏠 [🔒Reels][🔒Exp] 🔔 👤│ ← nav bar ALWAYS visible, only 2 icons capped
 *  └──────────────────────────┘
 *
 *  STORY VIEWER
 *  ┌──────────────────────────┐
 *  │  Story content  (free)   │ ← horizontal swipe between stories works
 *  ├──────────────────────────┤ ← 80 % down
 *  │  ▓ STRIP  (touch block)  │ ← blocks downward swipe exit to feed
 *  ├──────────────────────────┤ ← navBar.top (nav visible below)
 *  └──────────────────────────┘
 *
 *  REELS / EXPLORE (full screen)
 *  ┌──────────────────────────┐
 *  │  🚫 FULL BLOCK + quote   │ ← entire screen, tap shows quote
 *  └──────────────────────────┘
 *
 *  OTHER PROFILE
 *  ┌──────────────────────────┐
 *  │  Header / Follow btn     │ ← free (avatar, name, bio)
 *  ├──────────────────────────┤ ← below Follow/Message button
 *  │  🔒 PROFILE BLOCK        │ ← hides highlights + posts grid
 *  ├──────────────────────────┤
 *  │  nav bar  (visible)      │
 *  └──────────────────────────┘
 *
 *  DMS / OWN PROFILE / OTHER → zero overlay, full access
 */
class FocusService : AccessibilityService() {

    /* ════════════════════════════════════════════
       SCREEN ENUM
       ════════════════════════════════════════════ */
    private enum class S {
        HOME,           // Home feed with story row visible
        STORY,          // Full-screen story viewer
        REELS,          // Reels player
        EXPLORE,        // Explore / Search tab
        OTHER_PROFILE,  // Someone else's profile page
        OWN_PROFILE,    // User's own profile (Edit profile visible)
        DMS,            // Direct messages / inbox
        OTHER           // Settings, notifications, etc.
    }

    /* ════════════════════════════════════════════
       OVERLAY WRAPPER
       Pre-created once; show/hide by resizing via updateViewLayout
       (much faster than addView / removeView on every event).
       ════════════════════════════════════════════ */
    private inner class Ov(private val build: () -> View) {

        // View is created lazily on first show() call
        val v: View by lazy(LazyThreadSafetyMode.NONE) { build() }

        val lp: LayoutParams = LayoutParams(
            0, 0, 0, 0,
            TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        private var attached = false

        /** Show / reposition this overlay */
        fun show(b: Rect, passTouch: Boolean = false) {
            lp.x = b.left;  lp.y      = b.top
            lp.width = b.width(); lp.height = b.height()
            lp.flags = FLAG_NOT_FOCUSABLE or if (passTouch) FLAG_NOT_TOUCHABLE else 0
            commit()
        }

        /** Hide without detaching (resize to 0×0) — avoids Binder overhead */
        fun hide() {
            if (!attached) return
            lp.width = 0; lp.height = 0
            runCatching { wm.updateViewLayout(v, lp) }.onFailure { attached = false }
        }

        /** Permanently remove — called only on service destroy */
        fun drop() {
            if (attached) runCatching { wm.removeView(v) }
            attached = false
        }

        private fun commit() {
            if (attached) {
                runCatching { wm.updateViewLayout(v, lp) }
                    .onFailure { attached = false; commit() }
            } else {
                if (lp.width > 0 && lp.height > 0)
                    runCatching { wm.addView(v, lp); attached = true }
            }
        }
    }

    /* ════════════════════════════════════════════
       FIELDS
       ════════════════════════════════════════════ */
    private lateinit var wm: WindowManager

    // Overlay instances — initialised in onServiceConnected
    private lateinit var ovFeed:    Ov   // home feed blocker → tap = open DMs
    private lateinit var ovReels:   Ov   // full-screen Reels block
    private lateinit var ovExplore: Ov   // full-screen Explore block
    private lateinit var ovProfile: Ov   // other profile content block
    private lateinit var ovStory:   Ov   // thin strip in story viewer (blocks exit swipe)
    private lateinit var ovNReel:   Ov   // Reels nav icon cap
    private lateinit var ovNExp:    Ov   // Explore nav icon cap
    private val allOvs = mutableListOf<Ov>()

    private var igOpen = false
    private var scr = S.OTHER

    private val ui = Handler(Looper.getMainLooper())
    private val doRefresh = Runnable { refresh() }
    private val doApply   = Runnable { applyOverlays() }

    /* ════════════════════════════════════════════
       INSTAGRAM THEME PALETTE
       Dark  bg=#000000  primary=#FFFFFF  sub=#8E8E8E  sep=#262626
       Light bg=#FAFAFA  primary=#000000  sub=#737373  sep=#DBDBDB
       ════════════════════════════════════════════ */
    private val night: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                 Configuration.UI_MODE_NIGHT_YES

    private val cBg      get() = if (night) Color.argb(246,   0,  0,  0) else Color.argb(246, 250,250,250)
    private val cSurface get() = if (night) Color.argb(255,  18, 18, 18) else Color.argb(255, 255,255,255)
    private val cText    get() = if (night) Color.WHITE                    else Color.argb(255,   0,  0,  0)
    private val cSub     get() = if (night) Color.argb(255, 142,142,142)   else Color.argb(255, 115,115,115)
    private val cSep     get() = if (night) Color.argb(255,  38, 38, 38)   else Color.argb(255, 219,219,219)
    private val cBlue    = Color.argb(255,   0,149,246)   // #0095F6 Instagram blue
    private val cStrip   get() = if (night) Color.argb(200,   0,  0,  0)   else Color.argb(200, 230,230,230)

    private val QUOTES = arrayOf(
        "Real life  >  Reel life.",
        "Protect your attention.\nIt's your most valuable asset.",
        "Create more than you consume.",
        "Every moment spent scrolling\nis a moment not lived.",
        "Your focus is your superpower.",
        "Discipline bridges goals\nto achievement.",
        "Deep work beats shallow scrolling.",
        "Be present. Right now.",
        "Guard your mind.\nFeed it with purpose.",
        "What you do today\nshapes who you become."
    )

    /* ════════════════════════════════════════════
       LIFECYCLE
       ════════════════════════════════════════════ */
    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Pre-create all overlay wrappers (views built lazily on first show)
        fun mk(b: () -> View) = Ov(b).also { allOvs.add(it) }
        ovFeed    = mk { feedView() }
        ovReels   = mk { blockView("🚫", "Reels blocked",   QUOTES.random()) }
        ovExplore = mk { blockView("🔍", "Explore blocked", QUOTES.random()) }
        ovProfile = mk { profileView() }
        ovStory   = mk { storyStripView() }
        ovNReel   = mk { navCapView("🎯") }
        ovNExp    = mk { navCapView("✕")  }

        // If Instagram was already open when service was enabled
        ui.postDelayed({
            rootInActiveWindow?.let { r ->
                if (r.packageName?.toString() == "com.instagram.android") {
                    igOpen = true; setInstagramMode()
                    ui.post(doRefresh)
                }
                r.recycle()
            }
        }, 500)
    }

    override fun onInterrupt() = allOvs.forEach { it.hide() }
    override fun onDestroy()   { super.onDestroy(); allOvs.forEach { it.drop() } }

    /* ════════════════════════════════════════════
       EVENT ROUTING
       ════════════════════════════════════════════ */
    override fun onAccessibilityEvent(ev: AccessibilityEvent) {
        val pkg = ev.packageName?.toString() ?: return

        if (pkg == "com.instagram.android") {
            if (!igOpen) { igOpen = true; setInstagramMode() }

            if (ev.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                val cls = ev.className?.toString()?.lowercase() ?: ""
                when {
                    // Instant screen switch from window class name — no tree walk needed
                    "story" in cls -> instant(S.STORY)
                    "direct"  in cls ||
                    "thread"  in cls ||
                    "inbox"   in cls -> instant(S.DMS)
                    else -> schedule()
                }
            } else {
                schedule()
            }
        } else {
            if (igOpen) {
                igOpen = false
                setIdleMode()
                ui.removeCallbacks(doRefresh)
                ui.removeCallbacks(doApply)
                ui.post { allOvs.forEach { it.hide() } }
            }
        }
    }

    /** Apply a screen immediately without a tree walk */
    private fun instant(s: S) {
        ui.removeCallbacks(doRefresh)
        ui.removeCallbacks(doApply)
        scr = s
        ui.post(doApply)
    }

    /** Schedule a tree-walk classify + apply in 50 ms */
    private fun schedule() {
        ui.removeCallbacks(doRefresh)
        ui.postDelayed(doRefresh, 50)
    }

    /** Full event mode while Instagram is in foreground */
    private fun setInstagramMode() {
        val i = serviceInfo ?: return
        i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                       AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        i.packageNames = arrayOf("com.instagram.android")
        i.notificationTimeout = 50
        serviceInfo = i
    }

    /** Minimal mode while Instagram is in background — saves battery */
    private fun setIdleMode() {
        val i = serviceInfo ?: return
        i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        i.packageNames = null
        i.notificationTimeout = 200
        serviceInfo = i
    }

    /* ════════════════════════════════════════════
       SCREEN CLASSIFICATION  (tree-walk path)
       ════════════════════════════════════════════ */
    private fun refresh() {
        if (!igOpen) return
        val root = rootInActiveWindow ?: run {
            ui.postDelayed(doRefresh, 80)   // retry if root not ready
            return
        }
        scr = classify(root)
        root.recycle()
        applyOverlays()
    }

    private fun classify(root: AccessibilityNodeInfo): S {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels

        // 1. Reels: Like/Comment/Audio in right column at mid-screen
        if (rightColAction(root, sw, sh)) return S.REELS

        // 2. Explore/Search: wide search bar at very top
        if (topWideSearch(root, sw, sh)) return S.EXPLORE

        // 3. Story viewer: "Send message" / "Reply" input at lower screen
        if (storyInput(root, sh)) return S.STORY

        // 4. Own profile: "Edit profile" button present
        if (hasText(root, "Edit profile", sh * 0.55f)) return S.OWN_PROFILE

        // 5. Other profile: "Follow" button visible in top half
        if (hasText(root, "Follow", sh * 0.50f)) return S.OTHER_PROFILE

        // 6. DMs: message compose field at bottom ("Message...", "Aa")
        if (hasText(root, "Message...", sh.toFloat()) ||
            hasText(root, "Aa", sh.toFloat())) return S.DMS

        // 7. Home: story row ("Your story") visible
        if (hasText(root, "Your story", sh.toFloat())) return S.HOME

        return S.OTHER
    }

    private fun rightColAction(root: AccessibilityNodeInfo, sw: Int, sh: Int): Boolean {
        for (t in listOf("Like", "Comment", "Audio")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                if (b.left > sw * 0.62f && b.top > sh * 0.20f && b.bottom < sh * 0.93f) return true
            }
        }
        return false
    }

    private fun topWideSearch(root: AccessibilityNodeInfo, sw: Int, sh: Int): Boolean {
        for (n in root.findAccessibilityNodeInfosByText("Search")) {
            val b = Rect(); n.getBoundsInScreen(b); n.recycle()
            if (b.top < sh * 0.14f && b.width() > sw * 0.38f) return true
        }
        return false
    }

    private fun storyInput(root: AccessibilityNodeInfo, sh: Int): Boolean {
        for (t in listOf("Send message", "Reply")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                if (b.top > sh * 0.70f) return true
            }
        }
        return false
    }

    private fun hasText(root: AccessibilityNodeInfo, text: String, maxY: Float): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text)
        var found = false
        for (n in nodes) {
            val b = Rect(); n.getBoundsInScreen(b); n.recycle()
            if (!b.isEmpty && b.top < maxY) { found = true; break }
        }
        return found
    }

    /* ════════════════════════════════════════════
       OVERLAY APPLICATION
       ════════════════════════════════════════════ */
    private fun applyOverlays() {
        if (!igOpen) return
        val root = rootInActiveWindow
        val dm   = resources.displayMetrics
        val sw   = dm.widthPixels; val sh = dm.heightPixels

        // Nav bar bounds (needed for all screens)
        val navB = root?.let { findNavBar(it, sw, sh) }
        val navH = navB?.height() ?: dp(58)
        val navT = navB?.top ?: (sh - navH)

        // Reels + Explore nav icon positions
        val rtB = root?.let { findNavIcon(it, sh, listOf("Reels", "Reels tab")) }
        val exB = root?.let { findNavIcon(it, sh, listOf("Search tab", "Explore tab", "Search")) }

        // Always cap the Reels and Explore nav icons (on every Instagram screen)
        ovNReel.show(rtB ?: Rect(sw / 5 * 2, sh - navH, sw / 5 * 3, sh))
        ovNExp.show( exB ?: Rect(sw / 5 * 3, sh - navH, sw / 5 * 4, sh))

        when (scr) {

            S.HOME -> {
                ovReels.hide(); ovExplore.hide(); ovProfile.hide(); ovStory.hide()
                val stBot = root?.let { findStoryBottom(it) } ?: dp(265)
                val feedH = navT - stBot
                if (feedH > dp(40))
                    ovFeed.show(Rect(0, stBot, sw, navT))
                else
                    ovFeed.hide()
            }

            S.STORY -> {
                ovFeed.hide(); ovReels.hide(); ovExplore.hide(); ovProfile.hide()
                // Thin touch-blocking strip at the bottom of the story viewer.
                // Intercepts downward swipe attempts before they exit to the feed.
                // The top 80 % of the screen is untouched so horizontal story
                // navigation still works normally.
                val stripH   = dp(100)
                val stripTop = sh - navH - stripH
                ovStory.show(Rect(0, maxOf(stripTop, (sh * 0.80f).toInt()), sw, sh - navH))
            }

            S.REELS -> {
                ovFeed.hide(); ovExplore.hide(); ovProfile.hide(); ovStory.hide()
                ovReels.show(Rect(0, 0, sw, sh))   // full screen
            }

            S.EXPLORE -> {
                ovFeed.hide(); ovReels.hide(); ovProfile.hide(); ovStory.hide()
                ovExplore.show(Rect(0, 0, sw, sh)) // full screen
            }

            S.OTHER_PROFILE -> {
                ovFeed.hide(); ovReels.hide(); ovExplore.hide(); ovStory.hide()
                val cTop = root?.let { findProfileContentTop(it, sh) }
                    ?: (sh * 0.40f).toInt()
                if (navT > cTop + dp(30))
                    ovProfile.show(Rect(0, cTop, sw, navT))
                else
                    ovProfile.hide()
            }

            // Full access — no content overlays
            S.DMS, S.OWN_PROFILE, S.OTHER -> {
                ovFeed.hide(); ovReels.hide(); ovExplore.hide()
                ovProfile.hide(); ovStory.hide()
            }
        }

        root?.recycle()
    }

    /* ════════════════════════════════════════════
       ELEMENT FINDERS
       ════════════════════════════════════════════ */

    /**
     * Bottom edge of the story row.
     * "Your story" label sits at the very bottom of its circle element,
     * so its .bottom coordinate is the bottom of the entire story row.
     */
    private fun findStoryBottom(root: AccessibilityNodeInfo): Int {
        for (t in listOf("Your story", "Add to story")) {
            val nodes = root.findAccessibilityNodeInfosByText(t)
            if (nodes.isNotEmpty()) {
                val b = Rect(); nodes[0].getBoundsInScreen(b)
                nodes.forEach { it.recycle() }
                return b.bottom + dp(4)
            }
        }
        return dp(265)   // fallback: typical story row height on most devices
    }

    /** Recursively find the bottom nav bar: wide + short + at screen bottom */
    private fun findNavBar(root: AccessibilityNodeInfo, sw: Int, sh: Int): Rect? =
        navSearch(root, sw, sh, dp(42), dp(82))

    private fun navSearch(n: AccessibilityNodeInfo, sw: Int, sh: Int, mn: Int, mx: Int): Rect? {
        val b = Rect().also { n.getBoundsInScreen(it) }
        if (b.width() > sw * 0.74 && b.height() in mn..mx && b.bottom >= sh - dp(20)) return b
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val f = navSearch(c, sw, sh, mn, mx); c.recycle()
            if (f != null) return f
        }
        return null
    }

    /**
     * Find a specific nav bar icon by its content description.
     * Must be in the bottom 25 % of the screen and narrow (icon, not post).
     */
    private fun findNavIcon(root: AccessibilityNodeInfo, sh: Int, terms: List<String>): Rect? {
        val threshold = sh * 0.75f
        for (t in terms) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                if (!b.isEmpty && b.top >= threshold && b.width() < dp(90)) return b
            }
        }
        return null
    }

    /**
     * Start of blocked profile content — just below the Follow / Message buttons.
     * This covers highlights + posts/reels grid.
     */
    private fun findProfileContentTop(root: AccessibilityNodeInfo, sh: Int): Int {
        for (t in listOf("Follow", "Message", "Following", "Unfollow")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val b = Rect(); n.getBoundsInScreen(b); n.recycle()
                if (b.top > sh * 0.05f && b.top < sh * 0.50f) return b.bottom + dp(14)
            }
        }
        return (sh * 0.40f).toInt()   // fallback ≈ where profile header ends
    }

    /* ════════════════════════════════════════════
       VIEW BUILDERS
       ════════════════════════════════════════════ */

    /**
     * Home feed blocker.
     * Tap anywhere → opens Instagram DMs.
     * Shows an Instagram-styled card with a CTA button.
     */
    private fun feedView(): View {
        val root = vll().also { ll ->
            ll.setOnClickListener { openDMs() }

            ll.addView(tv("💬", 32f, cText))

            ll.addView(tv("Your friends' content\nis in Direct Messages",
                16f, cText, bold = true).also {
                it.setPadding(0, dp(14), 0, dp(6))
            })

            ll.addView(tv("Tap to open DMs", 12f, cSub).also {
                it.setPadding(0, 0, 0, dp(24))
            })

            // IG-blue pill button
            val pill = FrameLayout(this).apply {
                setBackgroundColor(cBlue)
                setPadding(dp(32), dp(12), dp(32), dp(12))
                setOnClickListener { openDMs() }
            }
            pill.addView(tv("Open Messages  →", 14f, Color.WHITE, bold = true).apply {
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER })
            ll.addView(pill)
        }
        return root
    }

    /**
     * Full-screen block for Reels and Explore tabs.
     * Shows a motivational quote. Back gesture still exits via Android system nav.
     */
    private fun blockView(icon: String, title: String, quote: String): View =
        vll().also { ll ->
            ll.addView(tv(icon, 48f, cText))

            ll.addView(tv(title, 20f, cText, bold = true).also {
                it.setPadding(0, dp(18), 0, dp(10))
            })

            // Separator line matching Instagram's divider colour
            ll.addView(View(this).apply {
                setBackgroundColor(cSep)
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(1)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(18)
                }
            })

            ll.addView(tv(quote, 14f, cSub).also {
                it.setPadding(dp(24), 0, dp(24), dp(32))
                it.setLineSpacing(dp(4).toFloat(), 1f)
            })

            ll.addView(tv("← Back gesture  or  🏠 Home to return",
                12f, cSub).also { it.alpha = 0.55f })
        }

    /**
     * Other-profile content blocker.
     * Covers the highlights row + posts / reels grid.
     * No scrolling possible — overlay consumes all touches.
     */
    private fun profileView(): View =
        vll().also { ll ->
            ll.addView(tv("🔒", 26f, cText))
            ll.addView(tv("Content hidden", 14f, cText, bold = true).also {
                it.setPadding(0, dp(10), 0, dp(4))
            })
            ll.addView(tv("Posts, reels & highlights\nare not shown here",
                12f, cSub).also {
                it.alpha = 0.65f
                it.setLineSpacing(dp(3).toFloat(), 1f)
            })
        }

    /**
     * Story-viewer bottom strip.
     * A touch-blocking bar at the bottom of the story area.
     * Blocks downward swipe gestures that would exit the story
     * and land on the home feed. The top 80 % of the story is
     * unaffected so horizontal story-to-story navigation works.
     */
    private fun storyStripView(): View = View(this).apply {
        setBackgroundColor(cStrip)
        isClickable  = true   // consume touch events → blocks swipe-down exit
        isFocusable  = false
    }

    /**
     * Small nav-bar icon cap for the Reels and Explore icons.
     * Sits exactly over the icon; opacity matches Instagram's surface colour.
     */
    private fun navCapView(emoji: String): View =
        FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(
                tv(emoji, 17f, cText).apply { gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ).apply { gravity = Gravity.CENTER }
            )
        }

    /* ════════════════════════════════════════════
       DM REDIRECT
       ════════════════════════════════════════════ */

    private fun openDMs() {
        // Try Instagram's own URI scheme first (opens DM inbox directly)
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("instagram://direct-inbox")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }.onFailure {
            // Fallback: launch Instagram normally
            runCatching {
                val i = packageManager.getLaunchIntentForPackage("com.instagram.android")!!
                i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(i)
            }
        }
    }

    /* ════════════════════════════════════════════
       MINI UI HELPERS
       ════════════════════════════════════════════ */

    private fun vll() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity     = Gravity.CENTER
        setBackgroundColor(cBg)
        setPadding(dp(28), dp(28), dp(28), dp(28))
    }

    private fun tv(text: String, size: Float, col: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize  = size
            setTextColor(col)
            gravity        = Gravity.CENTER
            textAlignment  = View.TEXT_ALIGNMENT_CENTER
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
}
